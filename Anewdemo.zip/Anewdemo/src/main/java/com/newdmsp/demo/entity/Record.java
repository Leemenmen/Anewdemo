package com.newdmsp.demo.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.Value;

@Data
@ToString
@ApiModel(value = "代码记录实体类")
public class Record {
    @ApiModelProperty(value = "记录id")
    private Integer id;
    @ApiModelProperty(value = "实验id")
    private Integer expid;
    @ApiModelProperty(value = "学生id")
    private Integer sid;
    @ApiModelProperty(value = "班级id")
    private Integer gid;
    @ApiModelProperty(value = "实验结果")
    private String expresult;
    @ApiModelProperty(value = "实验过程")
    private String expprocess;
    @ApiModelProperty(value = "实验报告路径")
    private String recordurl;
    @ApiModelProperty(value = "实验代码路径")
    private String recordcode;
    @ApiModelProperty(value = "实验分数")
    private Float score;
    @ApiModelProperty(value = "上传时间")
    private String createTime;
    @ApiModelProperty(value = "修改次数")
    private Integer count;
    @ApiModelProperty(value = "最后一次提交时间")
    private String lastTime;

    @ApiModelProperty(value = "实验名称", required = true)
    private String expname;
    @ApiModelProperty(value = "实验任务,默认值无意义", example = "0")
    private String expwork;
    @ApiModelProperty(value = "用户id,默认值无意义", example = "0")
    private Integer uid;
    @ApiModelProperty(value = "用户名,默认值无意义", example = "0")
    private String username;
    @ApiModelProperty(value = "真实名称,默认值无意义", example = "0")
    private String realname;
}
