package com.newdmsp.demo.service.Impl;

import com.newdmsp.demo.dao.RecordMapper;
import com.newdmsp.demo.entity.Record;
import com.newdmsp.demo.service.RecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class RecordServiceImpl implements RecordService {

    @Resource
    RecordMapper recordMapper;

    @Override
    public int addRecord(Record record) {
        return recordMapper.addRecord(record);
    }

    @Override
    public int upRecord(String id, String score) {
        return recordMapper.upRecord(id,score);
    }

    @Override
    public Record fingRecord(Integer expId, Integer id) {
        return recordMapper.findRecord(expId, id);
    }

}
