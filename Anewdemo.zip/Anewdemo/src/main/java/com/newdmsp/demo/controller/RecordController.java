package com.newdmsp.demo.controller;

import com.newdmsp.demo.entity.Exp;
import com.newdmsp.demo.entity.Record;
import com.newdmsp.demo.entity.Share;
import com.newdmsp.demo.entity.User;
import com.newdmsp.demo.service.ExpService;
import com.newdmsp.demo.service.RecordService;
import com.newdmsp.demo.utils.Result;
import com.newdmsp.demo.utils.ResultUtil;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

@Slf4j
@Controller
@Api(tags = "实验报告管理")
public class RecordController {

    @Resource
    RecordService recordService;
    @Resource
    ExpService expService;

    /**
     * 填写实验报告
     *
     * @return
     */
    @PostMapping("/addRecord1")
    @ResponseBody
    public Object addRecord(Record book) {
//        log.info("===file=="+file);
        HashMap<String, Object> map = new HashMap<>();
        // 存储图书信息到数据库
        Integer flag = null;
        try {
            flag = recordService.addRecord(book);
            if (flag != 0) {
                map.put("msg", "ok");
                map.put("code", 0);
            } else {
                map.put("msg", "error");
                map.put("code", 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // 防止id重复
            map.put("msg", "error");
            map.put("code", 1);
        }

        return map;
    }

    /**
     * 保存上传的代码
     */
    @PostMapping("/upload")
    @ResponseBody
    public Object upload(@RequestParam("expname") String expname,
                         @RequestParam("gname") String gname,
                         MultipartFile file,
//                         String fileName,
                         HttpSession session) {
        HashMap<String, Object> map = new HashMap<>();
        User loginUser = (User) session.getAttribute("loginUser");
        // 上传图片
        // 存储地址
        String realPath = "D:\\Summary\\test";
        String father = realPath + "\\" + expname;
        String son = father + "\\" + gname;

        File fatherFile = new File(father);
        File sonFile = new File(son);
        if (!fatherFile.exists()) {
            fatherFile.mkdirs();
            sonFile.mkdirs();
        } else {
            if (!sonFile.exists()) {
                sonFile.mkdirs();
            }
        }
        // 获取文件后缀
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        // 文件名
        String newFileName = loginUser.getUsername() + "." + extension;
        //处理文件上传
        try {
            file.transferTo(new File(son, newFileName));
        } catch (IOException e) {
            e.printStackTrace();
            map.put("msg", "error");
            map.put("code", 1);
        }
        map.put("msg", "ok");
        map.put("code", 0);
        return map;
    }







    @ApiOperation(value = "新增共享", notes = "1. 读取传入值；2. 生成文件路径名；3. 若路径不存在则新建； 4. 保存文件到指定路径； 5.将该条记录保存在数据库中")
    @ApiImplicitParams({
            @ApiImplicitParam(type = "query",name = "expid",required = true),
            @ApiImplicitParam(type = "query",name = "expprocess",required = true),
            @ApiImplicitParam(type = "query",name = "expresult",required = true),
            @ApiImplicitParam(type = "query",name = "expname",required = true),

            // 这些值若是不定义，接口传入报错，值不会真正存入到数据库中
            @ApiImplicitParam(type = "query",name = "count",value = "下载次数",required = false, defaultValue = "0"),
            @ApiImplicitParam(type = "query",name = "gid",value = "班级名，不会存入数据库",required = false, defaultValue = "0"),
            @ApiImplicitParam(type = "query",name = "id",value = "不会影响数据库",required = false, defaultValue = "0"),
            @ApiImplicitParam(type = "query",name = "score",value = "不会存入数据库",required = false, defaultValue = "0"),
            @ApiImplicitParam(type = "query",name = "sid",value = "不会影响数据库",required = false, defaultValue = "0")
    })
    @RequestMapping(value = "/addRecord", method = RequestMethod.POST)
    @ResponseBody
    public Result addRecord(Record record,
                                @ApiParam(value = "上传文件", required = true) MultipartFile file, HttpSession session) {


        User user = (User)  session.getAttribute("loginUser");
        String fileName = user.getUsername()+ ".py";
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        record.setSid(user.getId());
        record.setGid(user.getGradeid());
        record.setRecordcode(fileName);
        record.setCreateTime(time);
        record.setLastTime(time);

        String pathString = null;

        String baseDir = System.getProperty("user.dir") + "/stuRecord";
        if (!new File(baseDir).exists()) {
            new File(baseDir).mkdirs();
        }

        pathString = baseDir + '/' + user.getGname() + '_' + record.getExpname();
        if (!new File(pathString).exists()) {
            new File(pathString).mkdirs();
        }

        try {

            file.transferTo(new File(pathString, fileName));
            if (recordService.addRecord(record)>0){
                return ResultUtil.success();
            }else {
                return ResultUtil.unSuccess();
            }

        } catch (Exception e) {
            e.printStackTrace();
            return ResultUtil.unSuccess();
        }
    }


    @ApiOperation(value = "教师实验报告打分", notes = "1. 教师对已经提交了实验报告的学生进行评分")
    @ResponseBody
    @PostMapping("/upRecord")
    public Object upRecord(@ApiParam(value = "分数", name = "score", required = true, type = "query") String score,
                           @ApiParam(value = "报告id", name = "id", required = true, type = "query") String id) {
        try {
            int num = recordService.upRecord(id, score);
            log.info("num=" + num);
            if (num > 0) {
                return ResultUtil.success();
            } else {
                return ResultUtil.unSuccess();
            }
        }catch (Exception e){
            return ResultUtil.unSuccess();
        }

    }

    @ApiOperation(value = "学生查看自己的实验报告", notes = "1. 根据传入值查找实验报告")
    @ResponseBody
    @GetMapping("/findRecord/{expId}")
    public Object findRecord(@ApiParam(value = "实验id", required = true)@PathVariable String expId, HttpSession session) {
        try {
            User user = (User) session.getAttribute("loginUser");
            Record record1 = recordService.fingRecord(Integer.valueOf(expId), user.getId());
            return ResultUtil.success(record1);
        } catch (Exception e) {
            return ResultUtil.unSuccess();
        }
    }

}
