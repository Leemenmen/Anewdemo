package com.newdmsp.demo.controller;

import com.newdmsp.demo.service.ShareService;
import com.newdmsp.demo.utils.Result;
import com.newdmsp.demo.utils.ResultUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Controller
@Api(tags = "文件管理")
public class FileController {

    @Resource
    ShareService shareService;

    /**
     * 读取指定路径的内容并返回到前端
     *
     * @param filepath
     * @return
     * @throws IOException
     */
    @ApiOperation(value = "读取代码", notes = "1. 路径解码； 2. 与当前目录拼接；3. 读取文件")
    @PostMapping("/readCode")
    @ResponseBody
    public Result readCode(@ApiParam(value = "文件路径", required = true, defaultValue = "dmspCode/数据获取爬虫代码示范.py") @RequestParam("codePath") String filepath) throws IOException {

        // 传入路径
        String path = URLDecoder.decode(filepath, "UTF-8");
//        log.info(filepath);
        log.info(path);

        // 当前系统路径
        String baseDir = System.getProperty("user.dir");
        log.info(baseDir);
        // 拼接
        File readCode = ResourceUtils.getFile(baseDir + "/" + path );
        log.info("读取代码路径");
        log.info(String.valueOf(readCode));


        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(readCode))) {
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                result.append(line + '\n');
            }
            return ResultUtil.success("读取成功", result);
        } catch (Exception e) {
            return ResultUtil.unSuccess("读取失败");
        }

    }

    /**
     * 下载指定路径的文件
     *
     * @param file
     * @param response
     */
    @ApiOperation(value = "文件下载",
            notes = "1. codepath(示例代码) 和 uploadepath(共享文件) 若是都不为空则默认下载的是 示例代码；" +
                    "2. 若下载共享文件，则需要将除 codepath 的其他字段都要填充" +
                    "3. 拼接文件路径； 3.1 直接下载； 3.2 若请求的是 共享文件，访问数据库将该文件count加1")
    @RequestMapping(value = "/downCode", method = RequestMethod.GET)
    public void download2(@ApiParam(value = "示例代码名称", required = true, defaultValue = "数据获取爬虫代码示范.py") @RequestParam("codepath") String file,
                          @ApiParam(value = "共享代码名称, 2022_06_16/2_095941_20220615160226_c.py", defaultValue = "null") @RequestParam("uploadpath") String upload,
                          @ApiParam(value = "共享代码id", defaultValue = "0") @RequestParam String id,
                          @ApiParam(value = "共享代码下载次数", defaultValue = "0") @RequestParam String count,
                          @ApiParam(value = "共享是0代码还是1数据", defaultValue = "0") @RequestParam String flag,
                          HttpServletResponse response) throws UnsupportedEncodingException {

        String filePath = "";
        String newfile = "";
        int signal = 0;
        // 1.拼接文件路径
        if ("null".equals(file)) {
            newfile = java.net.URLDecoder.decode(upload, "UTF-8");
            if ("0".equals(flag) ) {
                filePath = System.getProperty("user.dir") + "/shareFile/code/" + newfile;
            } else {
                filePath = System.getProperty("user.dir") + "/shareFile/data/" + newfile;
            }
            signal = 1;
        } else {

            filePath = System.getProperty("user.dir") + "/dmspCode/" + file;
            newfile = file;
        }
        log.info("下载路径");
        log.info(filePath);
        // 2.1 直接下载
        try {
            InputStream bis = new BufferedInputStream(new FileInputStream(filePath));
            String fileName = newfile;
            fileName = URLEncoder.encode(fileName, "UTF-8");
            response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
            response.setContentType("multipart/form-data");
            BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
            int len = 0;
            while ((len = bis.read()) != -1) {
                out.write(len);
                out.flush();

            }

            // 2.2 若请求的是文件是 共享文件，访问数据库将该文件count加1
            if (signal == 1 && Integer.parseInt(id) > 0) {

                shareService.updateShare(Integer.valueOf(id), Integer.parseInt(count) + 1);
            }
            out.close();
            bis.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @ApiOperation(value = "读取数据文件", notes = "1. 路径解码并拼接；2，读取并返回excel")
    @RequestMapping(value = "/readExcel", method = RequestMethod.GET)
    @ResponseBody
    public Result readExcel(@ApiParam(value = "数据文件路径", required = true, defaultValue = "shareFile/data/2022_06_16/2_095509_Trust_CAR.xlsx")@RequestParam("uploadPath") String upload) throws UnsupportedEncodingException {

//        log.info(upload);

        String filePath = System.getProperty("user.dir") + "/" + java.net.URLDecoder.decode(upload, "UTF-8");
//        log.info("===filepafth==="+filePath);
        try {

//            boolean xls = filePath.endsWith(".xls");
//            boolean xlsx = filePath.endsWith(".xlsx");
            Workbook book;
            Sheet sheet = null;
            InputStream inputStream = new FileInputStream(new File(filePath));
            book = WorkbookFactory.create(inputStream);
            sheet = book.getSheetAt(0);
//            if (xls) {
//                // 解析excel
//                book = new HSSFWorkbook(inputStream);
//                //获取第一个表单sheet
//                sheet = book.getSheetAt(0);
//            }
//
//            if (xlsx) {
//                // 直接通过流获取整个excel
//                book = new XSSFWorkbook(inputStream);
//                // 获取第一个表单sheet
//                sheet = book.getSheetAt(0);
//            }

            if (sheet != null) {
                // 创建集合，保存每一行的每一列
                List<String> list = new ArrayList<>();
                // 获取第一行
                int firstRow = sheet.getFirstRowNum();
                // 获取最后一行
                int lastRow = sheet.getLastRowNum();
                list.add(String.valueOf(lastRow));
                // 循环行数依次获取列数
                for (int i = firstRow; i < lastRow + 1; i++) {
                    // 获取第 i 行
                    Row row = sheet.getRow(i);
                    if (row != null) {
                        // 获取此行的第一列
                        int firstCell = 0;

                        // 获取此行的存在数据的最后一列
                        int lastCell = row.getLastCellNum();

                        for (int j = firstCell; j < lastCell; j++) {

                            // 获取第 j 列
                            Cell cell = row.getCell(j);
                            if (cell != null) {
                                list.add(cell.toString());
                            } else {
                                list.add("");
                            }
                        }
                    }
                }
                return ResultUtil.success(list);
            }
            inputStream.close();
            return ResultUtil.unSuccess("文件格式错误");

        } catch (IOException e) {

            return ResultUtil.unSuccess("读取失败，稍后重试");

        }

    }

}
