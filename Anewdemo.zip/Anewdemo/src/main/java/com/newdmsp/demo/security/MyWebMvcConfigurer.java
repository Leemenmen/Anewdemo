package com.newdmsp.demo.security;

import org.springframework.web.servlet.config.annotation.*;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyWebMvcConfigurer implements WebMvcConfigurer {



    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**","/ace-builds-master/**","/fonts/**")
                .addResourceLocations("classpath:/static/","classpath:/static/ace-builds-master/","classpath:/static/fonts/");
        registry.addResourceHandler("/js/**").addResourceLocations("classpath:/static/js/");
        registry.addResourceHandler("/lib/**").addResourceLocations("classpath:/static/lib/");
        registry.addResourceHandler("/css/**").addResourceLocations("classpath:/static/css/");
        registry.addResourceHandler("/images/**").addResourceLocations("classpath:/static/images/");
        registry.addResourceHandler("/pictures/**").addResourceLocations("file:///F:/project/Anewdemo/stuCode/");
//        registry.addResourceHandler("/pictures/**").addResourceLocations("file:/opt/pubWebPro/stuCode/");


//        registry.addResourceHandler("/ac/**").addResourceLocations("classpath:/ac/**");


        WebMvcConfigurer.super.addResourceHandlers(registry);
    }
}
