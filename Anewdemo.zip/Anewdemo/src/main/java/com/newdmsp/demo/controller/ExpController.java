package com.newdmsp.demo.controller;

import com.newdmsp.demo.entity.Exp;
import com.newdmsp.demo.entity.History;
import com.newdmsp.demo.entity.RunResult;
import com.newdmsp.demo.entity.User;
import com.newdmsp.demo.service.ExpService;
import com.newdmsp.demo.utils.Result;
import com.newdmsp.demo.utils.ResultUtil;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Controller
@Api(tags = "实验管理")
public class ExpController {

//    static int i = 0;
    @Resource
    ExpService expService;

    @ResponseBody
    @RequestMapping("/test")
    public String getTest() {
        return "test";
    }

    @ApiOperation(value = "模糊查询", notes = "根据实验名称查询")
    @ApiImplicitParams({
            @ApiImplicitParam(type = "query", name = "expname", value = "实验名称", required = true, defaultValue = "null")
    })
    @ResponseBody
    @PostMapping("/getExps")
    public Result getExps(@ApiParam(value = "实验实体") Exp exp) {
        try {
            List<Exp> exps = expService.getExps(exp);
            if (exps != null) {
                return ResultUtil.success(exps);
            } else {
                return ResultUtil.success();
            }
        } catch (Exception e) {
            return ResultUtil.unSuccess();
        }

    }

    @ApiOperation(value = "实验细节", notes = "指定实验id返回实验细节")
    @ResponseBody
    @PostMapping("/getExpsByExpId/{expId}")
    public Result getExpsByExpId(@ApiParam(value = "实验id", required = true) @PathVariable("expId") Integer expId) {
        try {
            Exp exp = expService.getExpsByExpId(expId);
            return ResultUtil.success(exp);
        } catch (Exception e) {
            return ResultUtil.unSuccess();
        }
    }

    @ApiOperation(value = "实验名称", notes = "根据班级获取所有实验名称")
    @ResponseBody
    @PostMapping("/getExpsByGradeId/{gradeId}")
    public Result getExpsByGradeId(@ApiParam(value = "班级id") @PathVariable Integer gradeId) {
        try {
            List<Exp> exp = expService.getExpsByGradeId(gradeId);
            return ResultUtil.success(exp);
        } catch (Exception e) {
            return ResultUtil.unSuccess();
        }
    }

    @ApiOperation(value = "查询班级实验", notes = "获取班级和实验id、名称的映射")
    @ResponseBody
    @GetMapping("/gToe")
    public Result getGtoe() {
        try {
            List<Exp> exps = expService.getGtoe();
            return ResultUtil.success(exps);
        } catch (Exception e) {
            return ResultUtil.unSuccess();
        }

    }

    @ApiOperation(value = "查询教师班级实验", notes = "")
    @ResponseBody
    @GetMapping("/getGradeExp/{id}")
    public Result getGradeExp(@ApiParam(value = "教师id", name = "id", required = true) @PathVariable String id) {
        try {
            List<Exp> exps = expService.getTeachGradeExp(Integer.valueOf(id));
            return ResultUtil.success(exps);
        } catch (Exception e) {
            return ResultUtil.unSuccess();
        }

    }


    @ApiOperation(value = "新增实验", notes = "1. 设置上传路径; 2. 补充上传者id, 实验代码名称, 创建时间; 3. 文件上传、数据库新增记录")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "实验名称", name = "expname", type = "query", required = true),
            @ApiImplicitParam(value = "实验目的", name = "exptarget", type = "query", required = true),
            @ApiImplicitParam(value = "实验任务", name = "expwork", type = "query", required = true),
            @ApiImplicitParam(value = "实验代码名称", name = "expcodeurl", type = "query", required = true)
    })
    @PostMapping("/expUpload")
    @ResponseBody
    public Result expUpload(Exp exp,
                            @ApiParam(value = "上传文件") MultipartFile file, HttpSession session) throws IOException {


        // 1. 设置上传路径
        String baseDir = System.getProperty("user.dir") + "/dmspCode";
        if (!new File(baseDir).exists()) {
            new File(baseDir).mkdirs();
        }

        // 2. 补充上传者id, 实验代码名称, 创建时间
        String fileName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + "_" + exp.getExpcodeurl();
        User user = (User) session.getAttribute("loginUser");
        exp.setUpid(user.getId());
        exp.setExpcodeurl(fileName);
        exp.setCreateTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));

        // 3. 文件上传、数据库新增记录
        File newfile = new File(baseDir, fileName);
        try {
            //将文件上传到指定路径，并以新的名字命名
            file.transferTo(newfile);
            //在数据表中添加相应的一行信息
            int num = expService.addExp(exp);
            if (num > 0) {
                return ResultUtil.success("上传成功");
            } else {
                return ResultUtil.unSuccess("创建失败");
            }
        } catch (Exception e) {
            return ResultUtil.unSuccess("创建失败");
        }

    }

    @ApiOperation(value = "代码执行", notes = "1. 将前端编辑器中的代码编码传递到后台; 2. 判断存储历史代码的目录是否存在，不存在则创建; 3. 历史代码写入文件; 4. 代码运行,记录结果并写入到指定文件; 5. 数据库新增记录")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "实验id", name = "expId", type = "query", required = true)
    })
    @PostMapping("/runEditor")
    @ResponseBody
    public Result runeditor(@ApiParam(value = "代码", required = true, name = "context", type = "query") String context,
                            @ApiParam(value = "实验id", required = true, name = "expId") @RequestParam String expId, HttpSession session) {
        try {

            History history = new History();
            // 代码解码
            context = java.net.URLDecoder.decode(context, "UTF-8");


//            log.info(context);
            User user = (User) session.getAttribute("loginUser");
            // 父目录不存在新建
            String parentDir = System.getProperty("user.dir") + "/stuCode/";
            if (!new File(parentDir).exists()) {
                new File(parentDir).mkdirs();
            }
            // 历史代码文件名
            String RandomFilename = new SimpleDateFormat("yyyy_MM_dd_HHmmss").format(new Date());

            history.setExpId(Integer.valueOf(expId));
            history.setSid(user.getId());
            history.setSname(user.getUsername());
            history.setCodeurl(RandomFilename + "_code.py");
            history.setResulturl(RandomFilename + "_result.py");
//            log.info("===history==="+history);
            // 子目录不存在则新建
            String path = parentDir + user.getUsername() + "/";
            File newFile = new File(path);
            // 判断路径是否存在
            if (!newFile.exists()) {
                //不存在创建路径
                newFile.mkdirs();
            }
//
//            String str = "import sys\n" +
//                    " \n" +
//                    "sys.stdout = open('"+path+RandomFilename + "_result.py', mode = 'w',encoding='utf-8')\n";

            // 写入历史代码到文件
            BufferedWriter out = new BufferedWriter(new FileWriter(path + RandomFilename + "_code.py"));
            // 写入历史代码到文件
            BufferedWriter out1 = new BufferedWriter(new FileWriter(path + RandomFilename + "_0_code.py"));
            out.write(context);
            out.close();

//            String newContext = Replace("show\\(.*?\\)", context, "F:/project/Anewdemo/stuCode/" + user.getUsername() + "/" + RandomFilename + "_fig");
//            String newContext = Replace("show\\(.*?\\)", context, "/opt/pubWebPro/stuCode/" + user.getUsername() + "/" + RandomFilename + "_fig");

            int i =0;
            String newContext;
            String compile = "show\\(.*?\\)";
            String picName = "F:/project/Anewdemo/stuCode/" + user.getUsername() + "/" + RandomFilename + "_fig";
            Pattern p = Pattern.compile(compile);
            Matcher m = p.matcher(context);
            StringBuffer sb = new StringBuffer();
            boolean result1 = m.find();
            while (result1) {//如果匹配成功就替换
                m.appendReplacement(sb, "savefig('" + picName + "_" + i + ".png')");
                result1 = m.find();//继续下一步匹配
                i = i + 1;
            }
            if (i == 0) {
                newContext = context;
            } else {
                newContext = sb.toString();
            }

//            out1.write(str+newContext);
//            log.info(str+newContext);
            out1.write(newContext);
//            log.info(newContext);
            out1.close();

            // 记录运行结果
            StringBuilder result = new StringBuilder();
            // 执行python代码
            Process pr = Runtime.getRuntime().exec("python " + path + RandomFilename + "_0_code.py");
            // 记录执行结果
            BufferedReader in = new BufferedReader(new
                    InputStreamReader(pr.getInputStream(), "GB2312"));
            // 记录执行中出现的错误
            BufferedReader isError = new BufferedReader(new InputStreamReader(pr.getErrorStream(), "GB2312"));
            // 错误变量
            String errorline;
            // 输出变量
            String line;
            Integer tag = null;

            // 判断运行错误是否有值
            if ((errorline = isError.readLine()) != null) {
                tag = 1;
                result.append("代码运行有误，请检查后重新运行！！！\n");
                result.append(errorline).append('\n');
                //遍历错误值，并写入结果
                while ((errorline = isError.readLine()) != null) {
                    result.append(errorline).append('\n');
                }

                //判断输出变量里面值
                if ((line = in.readLine()) != null) {
//                    result.append("代码部分运行有误!!!");
                    result.append(line).append('\n');
                    //遍历输出值，并写入
                    while ((line = in.readLine()) != null) {
                        result.append(line).append('\n');
                    }
                } else {
                    in.close();
                    pr.waitFor();
                }
            } else {
                // 错误变量里面没有值，遍历输出变量的值
                if ((line = in.readLine()) == null) {
                    tag = 0;
                    result.append("代码没有输出");
                } else {
                    tag = 1;
                    result.append(line).append('\n');
                    while ((line = in.readLine()) != null) {
                        result.append(line).append('\n');
                    }
                }

            }
            // 代码运行结果写入结果文件中
//            writeResult(result, path, RandomFilename);
            BufferedWriter outResult = new BufferedWriter(new FileWriter(path + RandomFilename + "_result.py"));
            outResult.write(String.valueOf(result));
            outResult.close();

            history.setCreatetime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            history.setFigCount(i);

            RunResult runResult = new RunResult();
            runResult.setTag(String.valueOf(tag));
            runResult.setFigCount(i);
//            i = 0;
            runResult.setFigName(RandomFilename + "_fig");
            runResult.setCodeName("stuCode/" + user.getUsername() + "/" + RandomFilename + "_result.py");

            // 历史记录表中添加一条新的记录
            int num = expService.addHistory(history);
            if (num > 0) {
                return ResultUtil.success(runResult);
            } else {
                return ResultUtil.unSuccess();
            }

        } catch (Exception e) {
            return ResultUtil.error(e);
        }
    }

//    // 结果写入到指定文件中，并保存文件
//    private void writeResult(StringBuilder result, String path, String randomFilename) throws IOException {
////        log.info("==path+randomFilename+\"_result.py\"=="+path+randomFilename+"_result.py");
//        BufferedWriter out = new BufferedWriter(new FileWriter(path + randomFilename + "_result.py"));
//        out.write(String.valueOf(result));
//        out.close();
//    }
//
//    // .show()替换为.savefig()
//    public static String Replace(String compile, String context, String picName) {
//        Pattern p = Pattern.compile(compile);
//        Matcher m = p.matcher(context);
//        StringBuffer sb = new StringBuffer();
//        boolean result = m.find();
//        while (result) {//如果匹配成功就替换
//            m.appendReplacement(sb, "savefig('" + picName + "_" + i + ".png')");
//            result = m.find();//继续下一步匹配
//            i = i + 1;
//        }
//        if (i == 0) {
//            return context;
//        } else {
//            return sb.toString();
//        }
//    }


}
