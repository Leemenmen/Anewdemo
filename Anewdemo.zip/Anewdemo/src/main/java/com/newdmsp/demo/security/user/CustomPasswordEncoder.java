package com.newdmsp.demo.security.user;


import com.newdmsp.demo.security.RsaUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Slf4j
@Component
public class CustomPasswordEncoder implements PasswordEncoder {
//    @Resource
//    RsaUtil rsaUtil;

    @Override
    public String encode(CharSequence rawPassword) {
//        log.info((String) rawPassword);
        return rawPassword.toString();
    }

//    @Override
//    public boolean matches(CharSequence rawPassword, String encodedPassword) {
//        log.info((String) rawPassword,encodedPassword);
//        return encodedPassword.equals(rawPassword.toString());
//    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
//        log.info("传入密码");
//        log.info((String) rawPassword);
//        log.info("原始密码");
//        log.info(encodedPassword);
        String realPassword = RsaUtil.decrypt((String) rawPassword);
//        String decoderPassword = RsaUtil.decrypt(encodedPassword);
//        log.info("解码后传入密码");
//        log.info(realPassword);
//        log.info("解码数据库密码");
//        log.info(decoderPassword);
        return encodedPassword.equals(realPassword);
//        return decoderPassword.equals(realPassword);
    }


}
