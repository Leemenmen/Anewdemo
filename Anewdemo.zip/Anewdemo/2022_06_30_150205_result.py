<class 'numpy.ndarray'>
(4,)
