package com.newdmsp.demo.service;

import com.newdmsp.demo.entity.Record;

public interface RecordService {

    int addRecord(Record record);

    int upRecord(String id, String score);

    Record fingRecord(Integer expId, Integer id);
}
