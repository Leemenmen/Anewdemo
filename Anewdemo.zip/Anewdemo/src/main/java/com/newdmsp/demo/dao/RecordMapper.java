package com.newdmsp.demo.dao;

import com.newdmsp.demo.entity.Record;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface RecordMapper {

    int addRecord(Record record);

    int upRecord(String id, String score);

//    @Select("select * from exprecord where expid=#{expid} and sid=#{sid}")
    Record findRecord(Integer expId, Integer id);
}
